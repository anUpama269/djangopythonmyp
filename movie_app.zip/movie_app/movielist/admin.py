from django.contrib import admin

from movielist.models import Movies
admin.site.register(Movies)
