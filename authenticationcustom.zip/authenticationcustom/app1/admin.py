from django.contrib import admin
from app1.models import CustomUser
# Register your models here.
admin.site.register(CustomUser)
