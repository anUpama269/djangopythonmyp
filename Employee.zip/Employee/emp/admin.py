from django.contrib import admin
from emp.models import Employe
admin.site.register(Employe)

# Register your models here.
